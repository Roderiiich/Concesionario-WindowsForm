﻿using DemoCV.clases;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinFormsApp1
{
    public class GlobalVar
    {
        public static Inventario Inventario;
        public static Concesionario concesionario;
        public static List<Cliente> clientes;
        public static List<Vehiculo> vehiculos;
        
        public static List<Venta> ventas { get; set; }
    }

}
